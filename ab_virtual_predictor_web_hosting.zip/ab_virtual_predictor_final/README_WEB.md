# AB Virtual Predictor v23 — Web-Hosted Release

This is the web-hosting version of the final project. Unlike the original local package, it does not assume `127.0.0.1:8000`.

The server automatically uses the hosting platform's `PORT` and listens on `0.0.0.0`.

## Recommended deployment

Use **Render** or **Railway** with the included Dockerfile. The generated HTTPS address can then be opened directly from Safari on an iPhone.

### Render

- Push this folder to GitHub.
- Create a Render Blueprint from the repository.
- Render reads `render.yaml`.
- Open the generated HTTPS service URL.
- Verify `/api/health`.

### Railway

- Push this folder to GitHub.
- Create a Railway service from the repository.
- The Dockerfile is detected automatically.
- Mount persistent storage at `/data` if SQLite history must survive redeployments.
- Open the generated public HTTPS URL.

## Hosting variables

- `PORT`: supplied by the hosting platform
- `HOST`: defaults to `0.0.0.0`
- `DATA_DIR`: defaults to `./data`; use `/data` with a persistent volume
- `DB_FILENAME`: defaults to `predictor.db`
- `CORS_ORIGIN`: defaults to `*`

## Provider feed

The live and virtual provider connectors remain disabled by default. They can be enabled with the environment variables documented in `.env.example`.

They are read-only connectors and do not perform betting, staking, account login, or payment operations.

## Security

Before opening the dashboard to arbitrary public users, add authentication/access control at the hosting layer or application layer and consider rate limiting. The current project is a private research dashboard, not a full identity-management system.
