# AB Virtual Predictor 24.0 Final Packaged

## Windows
Double-click `run.bat`, then open http://127.0.0.1:8000

## macOS / Linux
Run:
```bash
./run.sh
```
Then open http://127.0.0.1:8000

## Check that it is running
```bash
python health_check.py
```
The API should report version `23.0-FINAL` because the underlying engine is the v23 final engine.

## Configuration
Copy `.env.example` to `.env` and adjust feed settings if needed. The feeds are read-only.

## Data
The SQLite database is created automatically as `predictor.db` after the server starts.
