import json, urllib.request, sys
url = sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8000/api/health'
with urllib.request.urlopen(url, timeout=5) as r:
    data=json.load(r)
print(json.dumps(data, indent=2))
