import csv, io, json, math, sqlite3, re, os, threading, time, hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from datetime import datetime, timezone

VERSION="23.0-FINAL"
DATA_DIR=os.getenv("DATA_DIR", "./data")
os.makedirs(DATA_DIR, exist_ok=True)
DB=os.path.join(DATA_DIR, os.getenv("DB_FILENAME", "predictor.db"))
HOST=os.getenv("HOST", "0.0.0.0")
PORT=int(os.getenv("PORT", "8000"))
CLASSES=["H","D","A"]

def now(): return datetime.now(timezone.utc).isoformat()
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS training(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      home TEXT, away TEXT, home_form REAL, away_form REAL,
      home_attack REAL, away_attack REAL, result TEXT,
      match_time TEXT, source TEXT, row_hash TEXT UNIQUE, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS predictions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, home TEXT, away TEXT,
      home_form REAL, away_form REAL, home_attack REAL, away_attack REAL,
      p_home REAL,p_draw REAL,p_away REAL,pick TEXT,confidence REAL,
      actual TEXT,model_version TEXT,created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS backtests(
      id INTEGER PRIMARY KEY AUTOINCREMENT, run_at TEXT, rows INTEGER,
      train_window INTEGER, test_rows INTEGER, models_json TEXT
    );
    CREATE TABLE IF NOT EXISTS live_events(
      event_id TEXT PRIMARY KEY, provider TEXT, home TEXT, away TEXT, start_time TEXT,
      status TEXT, tournament TEXT, category TEXT, odds_json TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS virtual_events(
      event_id TEXT PRIMARY KEY, provider TEXT, home TEXT, away TEXT, start_time TEXT,
      status TEXT, tournament TEXT, category TEXT, odds_json TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS feed_snapshots(
      id INTEGER PRIMARY KEY AUTOINCREMENT, feed TEXT, fetched_at TEXT, status TEXT,
      event_count INTEGER, duration_ms INTEGER, error TEXT
    );
    CREATE TABLE IF NOT EXISTS odds_history(
      id INTEGER PRIMARY KEY AUTOINCREMENT, feed TEXT, event_id TEXT, captured_at TEXT,
      p_home REAL, p_draw REAL, p_away REAL, raw_odds_json TEXT
    );
    CREATE TABLE IF NOT EXISTS virtual_results(
      id INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT, home TEXT, away TEXT,
      result TEXT, home_score INTEGER, away_score INTEGER, settled_at TEXT, source TEXT,
      p_home REAL, p_draw REAL, p_away REAL, pick TEXT, confidence REAL,
      UNIQUE(event_id, settled_at)
    );
    """); c.commit(); c.close()

def clean_result(x):
    x=str(x or "").strip().upper()
    return {"HOME":"H","HOME WIN":"H","1":"H","H":"H",
            "DRAW":"D","X":"D","0":"D","D":"D",
            "AWAY":"A","AWAY WIN":"A","2":"A","A":"A"}.get(x)

def num(x,default=None):
    try:
        v=float(str(x).strip())
        return max(0,min(1,v))
    except: return default

def feature(r):
    hf,af,ha,aa=[num(r[k],.5) for k in ("home_form","away_form","home_attack","away_attack")]
    # Engineered matchup features. They remain bounded so the models stay stable.
    form_gap=hf-af
    attack_gap=ha-aa
    home_strength=(hf+ha)/2
    away_strength=(af+aa)/2
    total_strength=(home_strength+away_strength)/2
    interaction=clamp(home_strength*ha,0,1)
    away_interaction=clamp(away_strength*aa,0,1)
    return [hf,af,ha,aa,form_gap,attack_gap,home_strength,away_strength,
            total_strength,interaction,away_interaction,1.0]

def clamp(x,a=0,b=1): return max(a,min(b,x))

def softmax(z):
    m=max(z); e=[math.exp(v-m) for v in z]; s=sum(e)
    return [x/s for x in e]


def build_team_history(rows):
    """Create leakage-safe rolling features from chronological match results.

    For each match, only prior matches for the two teams are used. If the input
    already contains form/attack values, they are retained as supplied; the
    generated fields provide additional diagnostics and can be used in future
    model versions.
    """
    team={}
    out=[]
    for r in rows:
        h=str(r.get("home","")).strip(); a=str(r.get("away","")).strip()
        if not h or not a: continue
        hp=team.get(h,{"n":0,"home":0,"away":0,"wins":0,"draws":0,"losses":0,"scored":0,"conceded":0})
        ap=team.get(a,{"n":0,"home":0,"away":0,"wins":0,"draws":0,"losses":0,"scored":0,"conceded":0})
        def rates(t):
            n=max(1,t["n"])
            return {
                "matches":t["n"],"win_rate":t["wins"]/n,"draw_rate":t["draws"]/n,
                "loss_rate":t["losses"]/n,"scored_rate":t["scored"]/n,
                "conceded_rate":t["conceded"]/n
            }
        q=dict(r); q["home_history"]=rates(hp); q["away_history"]=rates(ap)
        out.append(q)
        result=clean_result(r.get("result"))
        if result=="H":
            hp["wins"]+=1; hp["scored"]+=1; hp["conceded"]+=0
            ap["losses"]+=1; ap["scored"]+=0; ap["conceded"]+=1
        elif result=="A":
            hp["losses"]+=1; hp["scored"]+=0; hp["conceded"]+=1
            ap["wins"]+=1; ap["scored"]+=1; ap["conceded"]+=0
        elif result=="D":
            hp["draws"]+=1; ap["draws"]+=1
        hp["n"]+=1; ap["n"]+=1
        team[h]=hp; team[a]=ap
    return out

def normalize_rows(rows):
    out=[]
    for r in rows:
        if clean_result(r.get("result")) not in CLASSES: continue
        vals=[num(r.get(k),None) for k in ("home_form","away_form","home_attack","away_attack")]
        if any(v is None for v in vals): continue
        q=dict(r); q.update(dict(zip(("home_form","away_form","home_attack","away_attack"),vals)))
        q["result"]=clean_result(r["result"]); q["home"]=str(q.get("home","Home")).strip()
        q["away"]=str(q.get("away","Away")).strip()
        out.append(q)
    return out

def fit_logistic(rows,lr=.06,epochs=900):
    w=[[0.0]*12 for _ in range(3)]
    for _ in range(epochs):
        g=[[0.0]*12 for _ in range(3)]
        for r in rows:
            y=CLASSES.index(r["result"]); f=feature(r); p=softmax([sum(a*b for a,b in zip(wk,f)) for wk in w])
            for k in range(3):
                e=p[k]-(k==y)
                for j,x in enumerate(f): g[k][j]+=e*x
        n=max(1,len(rows))
        for k in range(3):
            for j in range(12): w[k][j]-=lr*g[k][j]/n
    return w

def pred_logistic(model,r):
    return softmax([sum(a*b for a,b in zip(w,feature(r))) for w in model])

def fit_naive(rows):
    # Gaussian Naive Bayes with smoothed class priors.
    model={}
    for c in CLASSES:
        rr=[r for r in rows if r["result"]==c]
        if not rr: rr=[]
        prior=(len(rr)+1)/(len(rows)+3)
        means=[]; vars_=[]
        for j in range(9):
            xs=[feature(r)[j] for r in rr]
            mu=sum(xs)/len(xs) if xs else .5
            va=sum((x-mu)**2 for x in xs)/len(xs) if len(xs)>1 else .08
            means.append(mu); vars_.append(max(va,.005))
        model[c]=(math.log(prior),means,vars_)
    return model

def pred_naive(model,r):
    f=feature(r); scores=[]
    for c in CLASSES:
        lp,mu,va=model[c]
        s=lp
        for x,m,v in zip(f,mu,va): s += -.5*math.log(2*math.pi*v)-(x-m)**2/(2*v)
        scores.append(s)
    return softmax(scores)

def fit_knn(rows,k=11):
    return list(rows),k

def pred_knn(model,r):
    rows,k=model; f=feature(r); ds=[]
    for q in rows:
        d=sum((a-b)**2 for a,b in zip(f,feature(q)))
        ds.append((d,q["result"]))
    ds.sort(key=lambda x:x[0]); top=ds[:min(k,len(ds))]
    weights=[0.0]*3
    for d,y in top: weights[CLASSES.index(y)]+=1/(math.sqrt(d)+.03)
    s=sum(weights)
    return [x/s for x in weights] if s else [1/3]*3

def fit_prior(rows):
    n=len(rows)
    return [(sum(r["result"]==c for r in rows)+1)/(n+3) for c in CLASSES]

def pred_prior(model,r): return list(model)

MODELS={"Logistic":(fit_logistic,pred_logistic),"Naive Bayes":(fit_naive,pred_naive),"KNN":(fit_knn,pred_knn),"Baseline":(fit_prior,pred_prior)}

def score(rows,probs):
    if not rows: return {"accuracy":None,"log_loss":None,"brier":None}
    acc=ll=br=0.0
    for r,p in zip(rows,probs):
        y=CLASSES.index(r["result"]); pred=max(range(3),key=lambda i:p[i])
        acc += pred==y; ll -= math.log(max(p[y],1e-12))
        br += sum((p[i]-(i==y))**2 for i in range(3))
    n=len(rows); return {"accuracy":acc/n,"log_loss":ll/n,"brier":br/n}

def ensemble(ps,weights=None):
    if not ps:return [1/3]*3
    if weights is None: weights=[1]*len(ps)
    s=sum(weights); return [sum(w*p[i] for w,p in zip(weights,ps))/s for i in range(3)]

def fit_all(rows):
    return {name:fit(rows) for name,(fit,pred) in MODELS.items()}

def predict_all(models,r):
    return {name:pred(models[name],r) for name,(fit,pred) in MODELS.items()}

def choose_ensemble(rows, models):
    # OOF-like validation: reserve the latest 25% to learn model weights.
    if len(rows)<12:return [1]*len(MODELS)
    cut=max(8,int(len(rows)*.75)); tr,va=rows[:cut],rows[cut:]
    vals=[]
    for name,(fit,pred) in MODELS.items():
        m=fit(tr); vals.append(score(va,[pred(m,r) for r in va])["log_loss"])
    inv=[1/max(v,1e-6) for v in vals]
    s=sum(inv); return [x/s for x in inv]

def walk_forward(rows,min_train=12,step=1):
    rows=list(rows); results={n:[] for n in MODELS}; ens=[]
    if len(rows)<=min_train:return {"error":f"Need more than {min_train} labeled rows."}
    for i in range(min_train,len(rows),step):
        tr=rows[:i]; te=rows[i:min(i+step,len(rows))]
        models=fit_all(tr); weights=choose_ensemble(tr,models)
        names=list(MODELS)
        for r in te:
            ps=predict_all(models,r)
            for n in names: results[n].append((r,ps[n]))
            ens.append((r,ensemble([ps[n] for n in names],weights)))
    summary={}
    for n,pairs in results.items(): summary[n]=score([r for r,p in pairs],[p for r,p in pairs])
    summary["Ensemble"]=score([r for r,p in ens],[p for r,p in ens])
    return {"test_rows":len(ens),"models":summary}

def data_quality(rows):
    total=len(rows); valid=len(normalize_rows(rows))
    seen=set(); dup=0
    for r in rows:
        key=(r.get("home","").strip().lower(),r.get("away","").strip().lower(),r.get("match_time",""),r.get("result",""))
        if key in seen:dup+=1
        seen.add(key)
    return {"received":total,"valid":valid,"duplicates":dup,"dropped":total-valid}

class Handler(BaseHTTPRequestHandler):
    def send_json(self,x,code=200):
        b=json.dumps(x).encode(); self.send_response(code); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin",os.getenv("CORS_ORIGIN","*"))
        self.send_header("Access-Control-Allow-Methods","GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        super().end_headers()
    def do_OPTIONS(self):
        self.send_response(204); self.end_headers()
    def body(self):
        return self.rfile.read(int(self.headers.get("Content-Length","0")))
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/":
            b=open("static/index.html","rb").read(); self.send_response(200); self.send_header("Content-Type","text/html"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b); return
        c=db()
        if p=="/api/health": self.send_json({"ok":True,"version":VERSION}); c.close(); return
        if p=="/api/stats":
            t=c.execute("select count(*) n from predictions").fetchone()["n"]; s=c.execute("select count(*) n from predictions where actual is not null").fetchone()["n"]; co=c.execute("select count(*) n from predictions where actual=pick").fetchone()["n"]; tr=c.execute("select count(*) n from training").fetchone()["n"]
            self.send_json({"predictions":t,"settled":s,"correct":co,"accuracy":co/s if s else None,"pending":t-s,"training_rows":tr}); c.close(); return
        if p=="/api/predictions":
            self.send_json([dict(r) for r in c.execute("select * from predictions order by id desc limit 300")]); c.close(); return
        if p=="/api/backtests":
            self.send_json([dict(r) for r in c.execute("select * from backtests order by id desc limit 20")]); c.close(); return
        if p=="/api/team-profile":
            team=str(urlparse(self.path).query.replace("team=","")).strip()
            rows=[dict(r) for r in c.execute("select * from training order by id")]
            hist=build_team_history(rows)
            matches=[r for r in hist if str(r.get("home","")).lower()==team.lower() or str(r.get("away","")).lower()==team.lower()]
            self.send_json({"team":team,"matches":len(matches),
                            "history":matches[-20:]})
            c.close(); return
        if p=="/api/data-quality":
            rows=[dict(r) for r in c.execute("select * from training order by id")]; self.send_json(data_quality(rows)); c.close(); return
        if p=="/api/engineered-history":
            rows=[dict(r) for r in c.execute("select * from training order by id")]
            engineered=build_team_history(rows)
            self.send_json(engineered); c.close(); return
        if p=="/api/training/export":
            rows=c.execute("select home,away,home_form,away_form,home_attack,away_attack,result,match_time,source from training order by id").fetchall()
            out=io.StringIO(); w=csv.writer(out); w.writerow(rows[0].keys() if rows else ["home","away","home_form","away_form","home_attack","away_attack","result","match_time","source"]); [w.writerow(list(r)) for r in rows]
            b=out.getvalue().encode(); self.send_response(200); self.send_header("Content-Type","text/csv"); self.end_headers(); self.wfile.write(b); c.close(); return
        c.close(); self.send_json({"error":"Not found"},404)
    def do_POST(self):
        p=urlparse(self.path).path
        try:
            data=json.loads(self.body() or b"{}"); c=db()
            if p=="/api/training/import_csv":
                raw=data.get("csv",""); rows=normalize_rows(list(csv.DictReader(io.StringIO(raw))))
                imported=skipped=0
                for r in rows:
                    key=f'{r["home"].lower()}|{r["away"].lower()}|{r.get("match_time","")}|{r["result"]}'
                    try:
                        c.execute("""insert into training(home,away,home_form,away_form,home_attack,away_attack,result,match_time,source,row_hash,created_at)
                        values(?,?,?,?,?,?,?,?,?,?,?)""",(r["home"],r["away"],r["home_form"],r["away_form"],r["home_attack"],r["away_attack"],r["result"],r.get("match_time",""),r.get("source","csv"),key,now())); imported+=1
                    except sqlite3.IntegrityError: skipped+=1
                c.commit(); self.send_json({"imported":imported,"skipped":skipped,"quality":data_quality(rows)})
            elif p=="/api/predict":
                r=data; models=fit_all([dict(x) for x in c.execute("select * from training order by id")])
                ps=predict_all(models,r); names=list(MODELS); weights=choose_ensemble([dict(x) for x in c.execute("select * from training order by id")],models)
                ep=ensemble([ps[n] for n in names],weights); i=max(range(3),key=lambda j:ep[j])
                vals=[num(r.get(k),.5) for k in ("home_form","away_form","home_attack","away_attack")]
                cur=c.execute("""insert into predictions(home,away,home_form,away_form,home_attack,away_attack,p_home,p_draw,p_away,pick,confidence,model_version,created_at) values(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (r.get("home","Home"),r.get("away","Away"),*vals,*ep,CLASSES[i],max(ep),VERSION,now())); c.commit()
                self.send_json({"id":cur.lastrowid,"ensemble":{"p_home":ep[0],"p_draw":ep[1],"p_away":ep[2],"pick":["Home","Draw","Away"][i],"confidence":max(ep)},"models":{n:{"p_home":ps[n][0],"p_draw":ps[n][1],"p_away":ps[n][2],"pick":["Home","Draw","Away"][max(range(3),key=lambda j:ps[n][j])]} for n in names},"weights":dict(zip(names,weights))})
            elif p=="/api/backtest/run":
                rows=[dict(r) for r in c.execute("select * from training order by id")]; result=walk_forward(rows,int(data.get("min_train",12)))
                c.execute("insert into backtests(run_at,rows,train_window,test_rows,models_json) values(?,?,?,?,?)",(now(),len(rows),int(data.get("min_train",12)),result.get("test_rows",0),json.dumps(result))); c.commit(); self.send_json(result)
            elif p=="/api/predictions/result":
                updated=0
                for r in data.get("rows",[]):
                    a=str(r.get("actual","")).title()
                    if a not in ["Home","Draw","Away"]: continue
                    if r.get("id"):
                        cur=c.execute("update predictions set actual=? where id=?",(a,int(r["id"]))); updated+=cur.rowcount
                c.commit(); self.send_json({"updated":updated})
            else:self.send_json({"error":"Not found"},404)
            c.close()
        except Exception as e:
            try:c.close()
            except:pass
            self.send_json({"error":str(e)},400)

# ---- Live / virtual feed platform (v20) -----------------------------------
LIVE_PROVIDER=os.getenv("LIVE_PROVIDER","sportybet")
SPORTYBET_BASE=os.getenv("SPORTYBET_BASE_URL","https://www.sportybet.com").rstrip("/")
SPORTYBET_REGION=os.getenv("SPORTYBET_REGION","gh")
SPORTYBET_POLL_SECONDS=float(os.getenv("SPORTYBET_POLL_SECONDS","20"))
SPORTYBET_TIMEOUT=float(os.getenv("SPORTYBET_TIMEOUT_SECONDS","12"))
SPORTYBET_ENABLED=os.getenv("SPORTYBET_ENABLED","false").lower()=="true"
SPORTYBET_VIRTUAL_ENABLED=os.getenv("SPORTYBET_VIRTUAL_ENABLED","false").lower()=="true"
SPORTYBET_VIRTUAL_URL=os.getenv("SPORTYBET_VIRTUAL_URL",f"{SPORTYBET_BASE}/{SPORTYBET_REGION}/m/instant-virtuals")
FEED_LOCK=threading.Lock()
FEED_STATE={"live":{"last_fetch":None,"last_ok":None,"last_count":0,"error":None},"virtual":{"last_fetch":None,"last_ok":None,"last_count":0,"error":None}}


def http_text(url,headers=None,timeout=12):
    import urllib.request
    req=urllib.request.Request(url,headers=headers or {"User-Agent":"AB-Virtual-Predictor/20"})
    with urllib.request.urlopen(req,timeout=timeout) as resp:
        return resp.read().decode("utf-8","replace")

def http_json(url,headers=None,timeout=12):
    return json.loads(http_text(url,headers,timeout))

def implied(odds):
    vals=[]
    for k in ("H","D","A"):
        try:
            o=float(odds.get(k,0)); vals.append(1/o if o>1e-9 else 0.0)
        except: vals.append(0.0)
    s=sum(vals)
    return [x/s for x in vals] if s else [None,None,None]

def normalize_live_events(payload):
    data=payload.get("data",payload) if isinstance(payload,dict) else {}
    tournaments=data.get("tournaments",[]) if isinstance(data,dict) else []
    events=[]
    for t in tournaments or []:
        for e in t.get("events",[]) or []:
            odds={}
            for m in e.get("markets",[]) or []:
                desc=str(m.get("desc","")).lower()
                if desc in ("1x2","3 way","3way","full time result","match result"):
                    for o in m.get("outcomes",[]) or []:
                        od=str(o.get("desc","")).lower()
                        key={"1":"H","x":"D","2":"A","home":"H","draw":"D","away":"A"}.get(od)
                        if key:
                            try: odds[key]=float(o.get("odds",0) or 0)
                            except: pass
            events.append({"provider":"sportybet","event_id":str(e.get("eventId") or ""),"home":e.get("homeTeamName","") or "","away":e.get("awayTeamName","") or "","start_time":e.get("estimateStartTime"),"status":e.get("matchStatus"),"odds":odds,"tournament":t.get("name","") or "","category":t.get("categoryName","") or ""})
    return [e for e in events if e["event_id"]]

def normalize_virtual_html(html):
    # The public Instant Virtuals page is JS-driven and can change shape. This
    # parser deliberately extracts only stable, visible fixture/odds patterns.
    if re.search(r"game unavailable|instant virtuals.*unavailable",html,re.I): return []
    compact=re.sub(r"\s+"," ",html)
    pat=re.compile(r"([A-Za-z0-9 .&'()/-]{2,40})\\s+(?:vs|v)\\s+([A-Za-z0-9 .&'()/-]{2,40})",re.I)
    out=[]; seen=set()
    for m in pat.finditer(compact):
        home=re.sub(r"<[^>]+>","",m.group(1)).strip(" -|")
        away=re.sub(r"<[^>]+>","",m.group(2)).strip(" -|")
        if not home or not away or home.lower()==away.lower(): continue
        key=(home.lower(),away.lower())
        if key in seen: continue
        seen.add(key)
        window=compact[m.end():m.end()+500]
        nums=re.findall(r"(?<![A-Za-z])([1-9][0-9]?\.[0-9]{2})(?![A-Za-z])",window)
        odds={}
        if len(nums)>=3:
            odds={"H":float(nums[0]),"D":float(nums[1]),"A":float(nums[2])}
        eid="vh-"+hashlib.sha1((home+"|"+away).encode()).hexdigest()[:16]
        out.append({"provider":"sportybet","event_id":eid,"home":home,"away":away,"start_time":None,"status":"scheduled","odds":odds,"tournament":"Instant Virtuals","category":"Virtual Football"})
    return out[:500]

def record_feed(feed,events,status="ok",error=None,duration_ms=0):
    table="live_events" if feed=="live" else "virtual_events"
    c=db(); nowv=now()
    for e in events:
        c.execute(f"""INSERT INTO {table}(event_id,provider,home,away,start_time,status,tournament,category,odds_json,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)
          ON CONFLICT(event_id) DO UPDATE SET home=excluded.home,away=excluded.away,start_time=excluded.start_time,status=excluded.status,tournament=excluded.tournament,category=excluded.category,odds_json=excluded.odds_json,updated_at=excluded.updated_at""",
          (e["event_id"],e.get("provider","sportybet"),e.get("home",""),e.get("away",""),e.get("start_time"),e.get("status"),e.get("tournament",""),e.get("category",""),json.dumps(e.get("odds",{})),nowv))
        p=implied(e.get("odds",{}))
        if all(x is not None for x in p):
            c.execute("insert into odds_history(feed,event_id,captured_at,p_home,p_draw,p_away,raw_odds_json) values(?,?,?,?,?,?,?)",(feed,e["event_id"],nowv,*p,json.dumps(e.get("odds",{}))))
    c.execute("insert into feed_snapshots(feed,fetched_at,status,event_count,duration_ms,error) values(?,?,?,?,?,?)",(feed,nowv,status,len(events),int(duration_ms),error))
    c.commit(); c.close()
    with FEED_LOCK:
        FEED_STATE[feed].update(last_fetch=nowv,last_ok=(status=="ok"),last_count=len(events),error=error)

def fetch_sportybet_events():
    if not SPORTYBET_ENABLED: return {"enabled":False,"events":[],"message":"Set SPORTYBET_ENABLED=true to activate the connector."}
    url=(f"{SPORTYBET_BASE}/api/{SPORTYBET_REGION}/factsCenter/pcUpcomingEvents?sportId=sr%3Asport%3A1&pageSize=100&pageNum=1&todayGames=false&timeline=720&_t={int(time.time()*1000)}")
    headers={"Accept":"application/json","Current-Country":SPORTYBET_REGION.upper(),"User-Agent":"AB-Virtual-Predictor/20"}
    return {"enabled":True,"events":normalize_live_events(http_json(url,headers,SPORTYBET_TIMEOUT))}

def fetch_virtual_events():
    if not SPORTYBET_VIRTUAL_ENABLED: return {"enabled":False,"events":[],"message":"Set SPORTYBET_VIRTUAL_ENABLED=true to activate the virtual connector."}
    html=http_text(SPORTYBET_VIRTUAL_URL,{"User-Agent":"AB-Virtual-Predictor/20"},SPORTYBET_TIMEOUT)
    unavailable=bool(re.search(r"game unavailable|instant virtuals.*unavailable",html,re.I))
    return {"enabled":True,"events":normalize_virtual_html(html),"unavailable":unavailable,"url":SPORTYBET_VIRTUAL_URL}

def refresh_feed(feed):
    started=time.time()
    try:
        result=fetch_sportybet_events() if feed=="live" else fetch_virtual_events()
        events=result.get("events",[]); status="unavailable" if result.get("unavailable") else "ok"
        record_feed(feed,events,status,None,round((time.time()-started)*1000))
        return result
    except Exception as e:
        record_feed(feed,[],"error",str(e),round((time.time()-started)*1000))
        with FEED_LOCK: FEED_STATE[feed].update(last_fetch=now(),last_ok=False,last_count=0,error=str(e))
        return {"enabled":True,"events":[],"error":str(e)}

def feed_worker():
    while True:
        if SPORTYBET_ENABLED: refresh_feed("live")
        if SPORTYBET_VIRTUAL_ENABLED: refresh_feed("virtual")
        time.sleep(max(5,SPORTYBET_POLL_SECONDS))

def db_events(feed,limit=200):
    c=db(); table="live_events" if feed=="live" else "virtual_events"
    rows=[dict(r) for r in c.execute(f"select * from {table} order by updated_at desc limit ?",(limit,))]; c.close()
    for r in rows:
        r["odds"]=json.loads(r.pop("odds_json") or "{}")
        r["implied"]=implied(r["odds"])
    return rows

def feed_health(feed):
    c=db(); table="live_events" if feed=="live" else "virtual_events"
    snap=c.execute("select * from feed_snapshots where feed=? order by id desc limit 1",(feed,)).fetchone()
    age=None
    if snap:
        try: age=max(0,time.time()-datetime.fromisoformat(snap["fetched_at"].replace("Z","+00:00")).timestamp())
        except: pass
    count=c.execute(f"select count(*) n from {table}").fetchone()["n"]
    c.close()
    with FEED_LOCK: state=dict(FEED_STATE[feed])
    state.update({"feed":feed,"stored_events":count,"last_snapshot":dict(snap) if snap else None,"age_seconds":age,"stale":age is not None and age>max(60,SPORTYBET_POLL_SECONDS*3)})
    return state


def team_feature_context(c, home, away, limit=20):
    """Build transparent pre-match features from previously stored team rows only."""
    rows=[dict(r) for r in c.execute("select * from training where lower(home)=lower(?) or lower(away)=lower(?) order by id desc limit ?",(home,away,limit*4))]
    def side(team):
        own=[]
        for r in rows:
            if str(r.get("home","")).lower()==team.lower():
                own.append((r.get("home_form"),r.get("home_attack"),r.get("result")))
            elif str(r.get("away","")).lower()==team.lower():
                own.append((r.get("away_form"),r.get("away_attack"),r.get("result")))
        own=own[:limit]
        if not own: return (.5,.5)
        f=[num(x[0],.5) for x in own]; a=[num(x[1],.5) for x in own]
        return (sum(f)/len(f),sum(a)/len(a))
    hf,ha=side(home); af,aa=side(away)
    return {"home":home,"away":away,"home_form":hf,"away_form":af,"home_attack":ha,"away_attack":aa,"history_rows":len(rows)}

def movement_summary(c, feed, event_id):
    rows=[dict(r) for r in c.execute("select * from odds_history where feed=? and event_id=? order by id",(feed,event_id))]
    if not rows: return {"count":0,"movement":None,"history":[]}
    first,last=rows[0],rows[-1]
    return {"count":len(rows),"first":first,"latest":last,
            "movement":{"home":last["p_home"]-first["p_home"],"draw":last["p_draw"]-first["p_draw"],"away":last["p_away"]-first["p_away"]},"history":rows[-50:]}


def virtual_metrics():
    c=db(); rows=[dict(r) for r in c.execute("select * from virtual_results where result is not null order by id")]; c.close()
    if not rows: return {"settled":0,"accuracy":None,"log_loss":None,"brier":None,"by_pick":{}}
    acc=ll=br=0.0; by={k:{"n":0,"correct":0} for k in ["H","D","A"]}
    for r in rows:
        y=CLASSES.index(r["result"]); ps=[r.get("p_home"),r.get("p_draw"),r.get("p_away")]
        if any(x is None for x in ps): continue
        pred=max(range(3),key=lambda i:ps[i]); acc += pred==y; ll -= math.log(max(ps[y],1e-12)); br += sum((ps[i]-(i==y))**2 for i in range(3))
        by[r["result"]]["n"]+=1; by[r["result"]]["correct"]+=pred==y
    n=max(1,len(rows)); return {"settled":len(rows),"accuracy":acc/n,"log_loss":ll/n,"brier":br/n,"by_pick":by}

def settle_virtual(event_id,result,home_score=None,away_score=None,source="manual"):
    result=clean_result(result)
    if result not in CLASSES: raise ValueError("result must be H, D or A")
    c=db(); r=c.execute("select * from virtual_events where event_id=?",(event_id,)).fetchone()
    if not r: c.close(); raise ValueError("virtual event not found")
    e=dict(r); odds=json.loads(e.get("odds_json") or "{}"); p=implied(odds); pick=CLASSES[max(range(3),key=lambda i:p[i])] if all(x is not None for x in p) else None; conf=max(p) if all(x is not None for x in p) else None
    c.execute("insert into virtual_results(event_id,home,away,result,home_score,away_score,settled_at,source,p_home,p_draw,p_away,pick,confidence) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",(event_id,e["home"],e["away"],result,home_score,away_score,now(),source,p[0],p[1],p[2],pick,conf))
    c.commit(); c.close(); return {"ok":True,"event_id":event_id,"result":result,"metrics":virtual_metrics()}

def market_prediction(e):
    p=implied(e.get("odds",{}));
    if any(x is None for x in p): return {"available":False,"reason":"No complete 1X2 odds"}
    i=max(range(3),key=lambda j:p[j]); return {"available":True,"method":"market-implied","p_home":p[0],"p_draw":p[1],"p_away":p[2],"pick":["Home","Draw","Away"][i],"confidence":p[i]}

# Extend Handler methods by wrapping the original GET/POST dispatch.
_ORIG_GET=Handler.do_GET
_ORIG_POST=Handler.do_POST

def extended_get(self):
    p=urlparse(self.path).path; q=parse_qs(urlparse(self.path).query)
    if p=="/api/live/status": self.send_json(feed_health("live")); return
    if p=="/api/virtual/status": self.send_json(feed_health("virtual")); return
    if p=="/api/live/events": self.send_json(db_events("live",int(q.get("limit",[200])[0]))); return
    if p=="/api/virtual/events": self.send_json(db_events("virtual",int(q.get("limit",[200])[0]))); return
    if p=="/api/live/fetch": self.send_json(refresh_feed("live")); return
    if p=="/api/virtual/fetch": self.send_json(refresh_feed("virtual")); return
    if p in ("/api/live/predict","/api/virtual/predict"):
        eid=q.get("event_id",[""])[0]; feed="live" if p.startswith("/api/live") else "virtual"; table="live_events" if feed=="live" else "virtual_events"
        c=db(); r=c.execute(f"select * from {table} where event_id=?",(eid,)).fetchone(); c.close()
        if not r: self.send_json({"error":"Event not found"},404); return
        e=dict(r); e["odds"]=json.loads(e.pop("odds_json") or "{}"); self.send_json({"event":e,"prediction":market_prediction(e)}); return
    if p=="/api/feed/health": self.send_json({"live":feed_health("live"),"virtual":feed_health("virtual")}); return
    if p=="/api/odds/history":
        eid=q.get("event_id",[""])[0]; c=db(); rows=[dict(r) for r in c.execute("select * from odds_history where event_id=? order by id desc limit 100",(eid,))]; c.close(); self.send_json(rows); return
    if p=="/api/feed/snapshots":
        feed=q.get("feed",["virtual"])[0]; c=db(); rows=[dict(r) for r in c.execute("select * from feed_snapshots where feed=? order by id desc limit 50",(feed,))]; c.close(); self.send_json(rows); return
    if p=="/api/odds/movement":
        feed=q.get("feed",["virtual"])[0]; eid=q.get("event_id",[""])[0]; c=db(); out=movement_summary(c,feed,eid); c.close(); self.send_json(out); return
    if p=="/api/model-market":
        feed=q.get("feed",["virtual"])[0]; eid=q.get("event_id",[""])[0]; table="live_events" if feed=="live" else "virtual_events"
        c=db(); r=c.execute(f"select * from {table} where event_id=?",(eid,)).fetchone()
        if not r: c.close(); self.send_json({"error":"Event not found"},404); return
        e=dict(r); e["odds"]=json.loads(e.pop("odds_json") or "{}")
        ctx=team_feature_context(c,e["home"],e["away"]); train=[dict(x) for x in c.execute("select * from training order by id")]
        result={"event":e,"context":ctx,"market":market_prediction(e)}
        if len(train)>=3:
            models=fit_all(train); ps=predict_all(models,ctx); weights=choose_ensemble(train,models); names=list(MODELS); mp=ensemble([ps[n] for n in names],weights)
            market=implied(e.get("odds",{}));
            result["model"]={"p_home":mp[0],"p_draw":mp[1],"p_away":mp[2],"pick":["Home","Draw","Away"][max(range(3),key=lambda j:mp[j])],"confidence":max(mp),"weights":dict(zip(names,weights))}
            result["comparison"]={"home":mp[0]-market[0] if market[0] is not None else None,"draw":mp[1]-market[1] if market[1] is not None else None,"away":mp[2]-market[2] if market[2] is not None else None}
        result["movement"]=movement_summary(c,feed,eid); c.close(); self.send_json(result); return
    if p=="/api/virtual/metrics": self.send_json(virtual_metrics()); return
    if p=="/api/virtual/results":
        c=db(); rows=[dict(r) for r in c.execute("select * from virtual_results order by id desc limit 200")]; c.close(); self.send_json(rows); return
    if p=="/api/virtual/walk-forward":
        c=db(); rows=[dict(r) for r in c.execute("select * from virtual_results where result is not null order by id")]; c.close();
        labeled=[]
        for r in rows:
            labeled.append({"home":r["home"],"away":r["away"],"home_form":r.get("p_home",.5),"away_form":r.get("p_away",.5),"home_attack":r.get("p_home",.5),"away_attack":r.get("p_away",.5),"result":r["result"]})
        self.send_json({"rows":len(labeled),"evaluation":walk_forward(labeled, min_train=12) if len(labeled)>12 else {"error":"Need more than 12 settled virtual results."}}); return
    _ORIG_GET(self)

def extended_post(self):
    p=urlparse(self.path).path
    if p=="/api/virtual/settle":
        try:
            data=json.loads(self.body() or b"{}"); out=settle_virtual(str(data.get("event_id","")),data.get("result"),data.get("home_score"),data.get("away_score"),str(data.get("source","manual"))); self.send_json(out); return
        except Exception as e: self.send_json({"error":str(e)},400); return
    if p=="/api/feed/refresh":
        data=json.loads(self.body() or b"{}"); feed=data.get("feed","virtual")
        if feed not in ("live","virtual"): self.send_json({"error":"feed must be live or virtual"},400); return
        self.send_json(refresh_feed(feed)); return
    _ORIG_POST(self)

def csv_response(self, rows, filename, columns=None):
    out=io.StringIO()
    if columns is None:
        columns=list(rows[0].keys()) if rows else []
    w=csv.writer(out); w.writerow(columns)
    for r in rows: w.writerow([r.get(k) for k in columns])
    b=out.getvalue().encode()
    self.send_response(200); self.send_header("Content-Type","text/csv; charset=utf-8"); self.send_header("Content-Disposition",f'attachment; filename="{filename}"'); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)

def final_get(self):
    p=urlparse(self.path).path; q=parse_qs(urlparse(self.path).query)
    if p=="/api/report":
        c=db();
        training=c.execute("select * from training order by id").fetchall(); preds=c.execute("select * from predictions order by id desc limit 1000").fetchall()
        vr=c.execute("select * from virtual_results order by id desc limit 1000").fetchall();
        fh={k:feed_health(k) for k in ("live","virtual")}; c.close()
        settled=[dict(x) for x in preds if x["actual"]]
        correct=sum(1 for x in settled if x["actual"]==x["pick"])
        return self.send_json({"version":VERSION,"generated_at":now(),"training_rows":len(training),"prediction_rows":len(preds),"settled_predictions":len(settled),"prediction_accuracy":correct/len(settled) if settled else None,"virtual_results":len(vr),"feed_health":fh,"virtual_metrics":virtual_metrics()})
    if p=="/api/metrics":
        return self.send_json({"prediction":self._metrics_prediction(),"virtual":virtual_metrics(),"feeds":{"live":feed_health("live"),"virtual":feed_health("virtual")}})
    if p=="/api/health-report":
        c=db(); tr=c.execute("select count(*) n from training").fetchone()["n"]; pr=c.execute("select count(*) n from predictions").fetchone()["n"]; vr=c.execute("select count(*) n from virtual_results").fetchone()["n"]; c.close()
        return self.send_json({"ok":True,"version":VERSION,"database":True,"training_rows":tr,"predictions":pr,"virtual_results":vr,"live_feed":feed_health("live"),"virtual_feed":feed_health("virtual")})
    if p=="/api/config":
        return self.send_json({"version":VERSION,"live_enabled":SPORTYBET_ENABLED,"virtual_enabled":SPORTYBET_VIRTUAL_ENABLED,"region":SPORTYBET_REGION,"poll_seconds":SPORTYBET_POLL_SECONDS,"read_only":True,"staking":False,"credentials_required":False})
    if p=="/api/export/predictions":
        c=db(); rows=[dict(r) for r in c.execute("select * from predictions order by id")]; c.close(); return csv_response(self,rows,"predictions.csv")
    if p=="/api/export/virtual-results":
        c=db(); rows=[dict(r) for r in c.execute("select * from virtual_results order by id")]; c.close(); return csv_response(self,rows,"virtual-results.csv")
    if p=="/api/export/odds-history":
        c=db(); rows=[dict(r) for r in c.execute("select * from odds_history order by id")]; c.close(); return csv_response(self,rows,"odds-history.csv")
    if p=="/api/virtual/events":
        # existing extended handler covers this; kept here only if ordering changes in future
        return extended_get(self)
    return extended_get(self)

# Small helper exposed to the final dashboard without changing existing prediction logic.
def _metrics_prediction(self):
    c=db(); rows=[dict(r) for r in c.execute("select * from predictions where actual is not null")]; c.close()
    if not rows: return {"settled":0,"accuracy":None}
    acc=sum(r["actual"]==r["pick"] for r in rows)/len(rows)
    ll=0.0; b=0.0
    for r in rows:
        probs={"Home":r["p_home"],"Draw":r["p_draw"],"Away":r["p_away"]}; p=max(1e-12,float(probs.get(r["actual"],1e-12))); ll-=math.log(p)
        y=[1.0 if r["actual"]==x else 0.0 for x in ("Home","Draw","Away")]; q=[r["p_home"],r["p_draw"],r["p_away"]]; b+=sum((a-z)**2 for a,z in zip(y,q))
    return {"settled":len(rows),"accuracy":acc,"log_loss":ll/len(rows),"brier":b/len(rows)}
Handler._metrics_prediction=_metrics_prediction
Handler.do_GET=final_get
Handler.do_POST=extended_post

if __name__=="__main__":
    init()
    threading.Thread(target=feed_worker,daemon=True).start()
    print(f"AB Virtual Predictor v{VERSION}: http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
