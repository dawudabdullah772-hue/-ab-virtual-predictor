# Web Quick Start

### Option A — Render

- Push this folder to GitHub.
- Create a Render Blueprint from the repo.
- Render reads `render.yaml`.
- Open the generated HTTPS URL.
- Check `/api/health`.

### Option B — Railway

- Push this folder to GitHub.
- Create a Railway service from the repo.
- Railway builds from the Dockerfile.
- Add a persistent `/data` volume.
- Open the generated HTTPS URL.

### Environment

`PORT` is supplied by the host. The app binds to `0.0.0.0` automatically.

For persistent SQLite storage:

`DATA_DIR=/data`

The app does not require pip dependencies.
