# Final packaged release

This package is the operational packaging of AB Virtual Predictor v23 Final.

Packaging improvements:
- explicit VERSION marker
- Windows launcher
- macOS/Linux launcher
- health-check utility
- quick-start guide
- release notes

The prediction engine remains the v23 final engine; no new predictive claims are introduced by this packaging release.
